const botaoMostraPalvras = dument.querySlector('#botao-palavraschave');

botaoMostraPalvras.addEventlistener('click', mostrapalavraschave);

function mostrapalavraschave(){
    const texto = cocument.querySelector('#entrada-de-texto'). value;
    const campoResultado = domcument.querySelector('#resultado-palavrachave')
    const palvra = texto .plot("");


    campoResultado.textContent = palavrasChave.join(", ");
}

function processaTexto(texto) {
    let palavras = texto.split(/\P{L}+/u);
    return palavras;
}
