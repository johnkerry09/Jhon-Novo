const botaoMostraPalvras = dument.querySlector('#botao-palavraschave');

botaoMostraPalvras.addEventlistener('click', mostrapalavraschave);

function mostrapalavraschave(){
    const texto = cocument.querySelector('#entrada-de-texto'). value;
    const campoResultado = domcument.querySelector('#resultado-palavrachave')
    const palvra = texto .plot("");


    campoResultado.textContent = palavrasChave.join(", ");
}

function processaTexto(texto) {
    let palavras = texto.split(/\P{L}+/u);

    let frequencias = []
    for(let i in palavras){
         frequencias[i] = 0;
        for ( let j in palavras) 
        if (palavras [i]==palavras[j]){
            frequencias[i]++;
        }
    }

    console.log(frequencias);
    return palavras;


   
}







