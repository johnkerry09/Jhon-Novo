const botaoMostraPalvras = dument.querySlector('#botao-palavraschave');

botaoMostraPalvras.addEventlistener('click', mostrapalavraschave);

function mostrapalavraschave(){
    const texto = cocument.querySelector('#entrada-de-texto'). value;
    const campoResultado = domcument.querySelector('#resultado-palavrachave')
    const palvra = texto .plot("");


    campoResultado.textContent = palavrasChave.join(", ");
}

function processaTexto(texto) {
    let palavras = texto.split(/\P{L}+/u);
    palavras = tira
    const freqencias = contafrequencias(palavras);
    let ordenadas = object.keys(frequencias).sort(oedenaPalavras);
    for(let i in palavras){
        palavras[i] = palavras[i].tolowercee();
    }
    function ordenapalavras( p1, p2){
        return frequencias[p2] - frequencias[p1];
    }

    console.log(ordenadas);
    return ordenadas.slice(0, 10);

 }
   function contafrquencias(palavras){
    let frequencias = {}
    for(let i in palavras){
         frequencias[i] = 0;
        for ( let j in palavras)
        frequencia [i] = 0
        for (let j of palavras)
       if (i == k) {
        frequencia[i]++;{

        
       }
        
        }
    }

    return  frequencias;
   }

function tiraPalavrasRUins(palavras){
    const PALAVRAS_RUNS = ["para", "uma","nós"];


    const palavrasBoas = [];
    for (let palavra of palavras){
        if(palavras. length > 2){
            palavrasBoas.puh(palavra);
        }
    }
}






